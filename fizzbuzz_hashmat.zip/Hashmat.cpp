//RAMOS, Ronaldo T. | 201512202
#include <iostream> 
#include <cmath>
using namespace std;
int main () { 
float a,b;
cout<<"Input ally soldiers: ";
cin >> a;
cout<<"Input enemy soldiers: ";
cin >> b;
a-=b;
cout<<abs(a);
return 0;
}